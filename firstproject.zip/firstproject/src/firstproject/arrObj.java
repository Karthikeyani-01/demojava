package firstproject;
class Student{
	int roll;
	String name;
	int marks;
}

public class arrObj {
	public static void main (String args[])
	{
		Student s1 = new Student();
		s1.roll = 1;
		s1.name="ganesh";
		s1.marks=55;
		
		
		Student s2 = new Student();
		s2.roll = 2;
		s2.name="gan";
		s2.marks=90;
		
		Student s3 = new Student();
		s3.roll = 3;
		s3.name="ganes";
		s3.marks=100;
		
		Student students[]=new Student[3];
		students[0]=s1;
		students[1]=s2;
		students[2]=s3;
		
		//for ( int i=0; i< students.length;i++)
	//	{
	//		System.out.println(students[i].roll+" " +students[i].name+" "+students[i].marks);
	//	}
		
		for(Student stud: students)
		{
			System.out.println(stud.roll+" " +stud.name+" "+stud.marks); // this is called enchanced for loop
		}
		
	}

}
//array of objects