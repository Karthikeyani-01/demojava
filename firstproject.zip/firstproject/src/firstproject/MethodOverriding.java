package firstproject;


class H
{
	public void show()
	{
		System.out.println("in h");
	}
	public void config()
	{
		System.out.println("in config");
	}
	public int add(int a, int b,int c)
	{
		return a+b+c;
	}
}
class J extends H
{
	public void show()
	{
		System.out.println("in J");
	}
	public int add(int a, int b)
	{
		return a+b+1;
	}
}
public class MethodOverriding {

	public static void main(String[] args) {
		J obj=new J();
		obj.show();
		obj.config();
		int r=obj.add(3, 2,9);
		System.out.println(r);
		
	}

}
