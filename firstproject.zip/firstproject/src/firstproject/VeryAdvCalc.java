package firstproject;

public class VeryAdvCalc extends AdvCalc {
 public double power(int a, int b)
 {
	 return Math.pow(a, b);
 }
}
