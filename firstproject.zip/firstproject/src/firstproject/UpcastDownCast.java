package firstproject;

class D
{
	public void show() {
		System.out.println("in d");
	}
}
class E extends D
{
	public void show1() {
		System.out.println("in e");
	}
}
public class UpcastDownCast {
	public static void main(String args[])
	{
		D obj=new E(); //up casting
		obj.show();
		E obj1=(E) obj; //down casting
		obj1.show1();
		
	}

}
