package firstproject;

public class wrapper {
	public static void main(String args[])
	{
		int n=7;
		Integer n1=n; //auto boxing 
		int n2=n1; //auto unboxing
		System.out.println(n2);
		System.out.println(n);
		System.out.println(n1);
	}

}
//autoboxing means storing primitive data types in the objects automatically
//auto unboxing : when we take out the primitive value from the object is called auto unboxing