package firstproject;

public class mulDimensionArray {
 public static void main(String args[])
 {
	 int mDa[][]= new int [3][4];
	 for ( int i =0; i<3;i++)
	 {
		 for(int j = 0;j<4;j++)
		 {
			 System.out.print(mDa[i][j]+" ");
		 }
		 System.out.println();
	 }
	 
	 
 }
}
