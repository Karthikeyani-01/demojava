package firstproject;

class Calclator
{
	public int add()
	{
		System.out.println("add" );
		return 0;
	}
}

public class first {

	public static void main (String [] args) {
		int num1=4;
		int num2=5;
		 Calclator calc=new Calclator();
		 calc.add();
		
		//System.out.println(x);
	}

}
