package firstproject;

public class arrayEx {
	public static void main(String args[])
	{
		int nums[]= {1,2,3,4};
		nums[3]=9;
		System.out.println(nums[3]);
		
		int nums1[]=new int [4];
		nums1[0]=1;
		nums1[1]=6;
		nums1[2]=10;
		nums1[3]=12;
		for(int i=0;i<4;i++)
		{
			System.out.println(nums1[i]);
		}
		
	}

}
