package firstproject;

class Mobile
{
	String brand; //instance var
	int price;     //instance
	static String name; //static var
	
		public void show()
		{
			System.out.println(brand+ " "+price+" "+name);
		}
		public static void show1(Mobile obj) // this is static method 
		{
			System.out.println(obj.brand+ " "+obj.price+" "+obj.name);
		}
	
}

public class StaticVar {

	public static void main(String[] args) {
		 Mobile obj1=new Mobile();
		 obj1.brand="apple";
		 obj1.price=577;
		 Mobile.name="sp";
		 
		 
		 Mobile obj2=new Mobile();
		 obj2.brand="Samsung";
		 obj2.price=579;
		 Mobile.name="Smartphone";
		 
		 obj1.show();
		 obj2.show();
		 Mobile.show1(obj2);
		 
	}

}
 //static variables are shared by different objects and if you want to refer
//to a static variable you can use a class name
//once we change static varibale any objects then other objects will also change
//static method or variables should be called by class