package firstproject;
class Comp
{
	public  void playMusic()
	{
		System.out.println( "Music");
	}

 
	public String getMeAPen(int cost)
	{
		if(cost>=10)
			return "pen";
		return "pencil";
	}
	
		
	
}
	

public class Methodprac {
	public static void main(String args[])
	{
		//int n=2;
		Comp obj = new Comp();
		obj.playMusic();
		String str=obj.getMeAPen(10);
		System.out.println(str);
		
	}

}
