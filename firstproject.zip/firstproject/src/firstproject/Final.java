package firstproject;

/*final */class Calcu{
	public /*final*/ void  show()
	{
		System.out.println("in calc");
	}
	public void add(int a ,int b)
	{
		System.out.println(a+b);
	}
}
class AdvanceCalc extends Calcu{
	public void show()
	{
		System.out.println("in advcalc");
	}
	
}

public class Final {

	public static void main(String[] args) {
		final int num=8;
		//num=9;
		System.out.println(num);
		//Calculator obj= new Calculator();
		 AdvanceCalc obj=new AdvanceCalc();
		 obj.add(3, 4);
		 obj.show();
		

	}

}

//final keyword can be used with a variable,method and with a class