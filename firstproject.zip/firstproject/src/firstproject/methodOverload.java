package firstproject;

class addNum {
	public int add(int a,int b,int c)
	{
		return a+b+c;
	}
	public int add (int a,int b)
	{
		return a+b;
	}
	public double add(double a,int b)
	{
		return a+b;
	}
	
}
public class methodOverload { 
	public static void main (String args[])
	{
		addNum obj1=new addNum();
		int res=obj1.add(5,6);
		System.out.println(res);
	}

}
/*method overloading means having same method names but different parameters
Method overloading in Java means having two or more methods (or functions) in a class with the same name
 and different arguments (or parameters). */