package firstproject;

class Huma
{
	private int age;
	private String name;
	
	
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	
}

public class ThisObj {
	public static void main(String args[])
	{
		Huma objec = new Huma();
		objec.setAge(25);
		objec.setName("ganesh");
		
		System.out.println(objec.getAge()+ " "+objec.getName());
	}

}
//this keyword represents the current obj (current obj =means the obj which is calling the method)