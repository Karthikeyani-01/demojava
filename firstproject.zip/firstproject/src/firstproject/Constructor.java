package firstproject;


class Humans
{
	private int age;
	private String name;
	
	
	
	
	public Humans() //default constructor
	{
		age=12;
		name="john";
	}
	public Humans(int a, String n) //parameterized constructor
	{
		age=a;
		name=n;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	
	
	
}

public class Constructor {
	public static void main(String args[])
	{
		Humans objec = new Humans();
//		String nm=objec.name;
		Humans objec1 = new Humans(18,"ganesh");
//		String nm1=objec1.name;
		System.out.println(objec.getAge()+ " "+objec.getName());
		System.out.println(objec1.getAge()+ " "+objec1.getName());
		objec.setAge(25);
		objec.setName("ganesh");
//		System.out.println(nm);
//		System.out.println(nm1);
		System.out.println(objec.getAge()+ " "+objec.getName());
	}
}//constructor lookslike methods
//constructor dont specify return type
//constructor should be same name as class
//even if we dontt call constructor will be called
//everytime u create a obj it will call the constructor
