package firstproject;

public class AdvCalc extends Calc{
	public int mul(int a , int b)
	{
		return a*b;
	}
	public int div(int a,int b)
	{
		return a/b;
	}
	

}
//AdvCalc is sub class and Calc is superclass and to inherit we use a 
//extend keyword and this is basically a relationship of is-a, advcalc is a calc
